#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
#define ll long long
#define str string
#define N 20
using namespace std;

int main(){
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY);
	vector<str> lin(1);
	int pl=0,px=0;
	system((str("mode con lines=")+to_string(N+5)+string(" cols=83")).c_str());
	printf("Press ^Q for help ...\n");
	Sleep(3000);
	while(1){
		system("cls");
		
		for(int i=max(0,pl-N/2);i<min(int(lin.size()),pl+N/2+1);i++){
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED|FOREGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY|BACKGROUND_BLUE);
			printf(" %3d ",i+1);
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY);
			printf(" ",i+1);
			for(int j=0;j<=lin[i].size();j++){
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_BLUE|FOREGROUND_GREEN);
				if(pl==i && px==j){
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_BLUE|BACKGROUND_GREEN|BACKGROUND_RED|BACKGROUND_BLUE);
					if(j==lin[i].size()) printf(" ");
				}
				if(j==lin[i].size()) printf("\n");
				else printf("%c",lin[i][j]);
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_BLUE|FOREGROUND_GREEN);
			}
		}
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED);
		printf("################################################################################\n");
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_GREEN);
		printf(" lin:%3d   col:%3d                                                     CPPeditor\n",pl,px);
		
		char c=getch();
		if(c=='\r'){
			lin.insert(lin.begin()+pl+1,lin[pl].substr(px));
			lin[pl]=lin[pl].substr(0,px);
			pl++;
			px=0;
		}
		else if(c==-32){
			switch(getch()){
				case 72:
					if(pl!=0){
						pl--;
						px=min(px,int(lin[pl].size()));
					}
					break;
				case 80:
					if(pl!=lin.size()-1){
						pl++;
						px=min(px,int(lin[pl].size()));
					}
					break;
				case 75:
					if(px!=0) px--;
					else if(pl!=0){
						pl--;
						px=lin[pl].size();
					}
					break;
				case 77:
					if(px!=lin[pl].size()) px++;
					else if(pl!=lin.size()-1){
						pl++;
						px=0;
					}
					break;
				default:
					break;
			}
		}
		else if(c=='\b'){
			if(px!=0) lin[pl].erase(--px,1);
			else if(pl!=0){
				px=lin[pl-1].size();
				lin[pl-1]+=lin[pl];
				lin.erase(lin.begin()+pl);
				pl--;
			}
		}
		else if(c>=' ' && c<='~' || c=='\t') lin[pl].insert(px++,1,c);
		else if(c==6){
			system("cls");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED|FOREGROUND_GREEN);
			for(int i=0;i<lin.size();i++) printf("%s\n",lin[i].c_str());
			printf("hint: Paste code? Ctrl+V ,then click right button.");
			system("notepad");
		}
		else if(c==17){
			system("cls");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED|FOREGROUND_GREEN);
			printf("This is CPPeditor!\nLight Safe and Pretty.\n  ^F:save/open file with notepad\n  ^R:run file on runoob\n  ^Q:help of CPPeditor\n  ^X:exit CPPeditor\nContact us: [1470185505@qq.com]\n");
			Sleep(5000);
		}
		else if(c==18) system("start https://c.runoob.com/compile/12/");
		else if(c==24){
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED|FOREGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY);
			system("cls");
			return 0;
		}
	}
}

